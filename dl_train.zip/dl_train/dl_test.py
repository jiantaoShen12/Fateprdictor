

import numpy as np

np.random.seed(0)

import pandas as pd


from tensorflow.keras.models import load_model

import time

start = time.time()

# Parse command line arguments
import argparse

parser = argparse.ArgumentParser(description="Test DL classifier")
parser.add_argument(
    "--use_inter_train",
    type=str,
    help="Use the intermediate training data as opposed to the hard saved training data",
    default="true",
)
parser.add_argument(
    "--use_inter_classifier",
    type=str,
    help="Use the intermediate classifier as opposed to the hard saved classifier",
    default="true",
)

args = parser.parse_args()
use_inter_train = True if args.use_inter_train == "true" else False
use_inter_classifier = True if args.use_inter_classifier == "true" else False
if use_inter_train:
    filepath_data = "/home/sjt/workspace/beginning_project/下载1/output_6(1.8)假20次pf_fold交错/"
else:
    filepath_data = "D:\\下载1\\5_100\\"

# 选择模型类型
model_type =1  # 可以根据需要更改为其他模型类型
a=4
if a == 1:
    filepath_classifier = "/home/sjt/workspace/beginning_project/下载1/output_6(1.8)假20次pf_fold交错/LSTM/"
elif a == 2:
    filepath_classifier = "/home/sjt/workspace/beginning_project/下载1/output_6(1.8)假20次pf_fold交错/GRU/"
elif a == 3:
    filepath_classifier = "/home/sjt/workspace/beginning_project/下载1/output_6(1.8)假20次pf_fold交错/BILSTM/"
elif a == 4:
    filepath_classifier = "/home/sjt/workspace/beginning_project/下载1/output_6(1.8)假20次pf_fold交错/RNN/"
elif a == 0:
    filepath_classifier = "/home/sjt/workspace/beginning_project/下载1/output_6(1.8)假20次pf_fold交错/"
#D:\python2\store\c\cell_change\dl_train\6test_output2\\blstm3\\xuan\\
#D:\python2\store\c\cell_change\dl_train\6test_output2\\GRU3\\xuan\\
#D:\python2\store\c\cell_change\dl_train\6test_output2\\lstm2\\xuan\\
#D:\python2\store\c\cell_change\dl_train\6test_output2\\rnn2\\xuan\\
#"D:\\下载1\\5_500\\
# Function to preprocess training/test data
ts_len = 500


def prepare_series(series, model_type):
    """
    Prepare raw series data for training.

    Parameters:
        series: pd.Series of length ts_len
    """

    # Length of sequence to extract
    L = np.random.choice(np.arange(50, ts_len + 1))

    # Start time of sequence to extract
    if model_type == 1:
        t0 = np.random.choice(np.arange(0, ts_len - L + 1))
    elif model_type == 2:
        t0 = ts_len - L

    seq = series.iloc[t0 : t0 + L]

    # Normalise the sequence by mean of absolute values
    mean = seq.abs().mean()
    seq_norm = seq / mean

    # Prepend with zeros to make sequence of length ts_len
    series_out = pd.concat(
        [pd.Series(np.zeros(ts_len - L)), seq_norm], ignore_index=True
    )

    # Keep original index
    series_out.index = series.index
    return series_out
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model

# 省略了之前的导入和函数定义...


# 加载模型
model = load_model(filepath_classifier + "classifier_{}.pkl".format(model_type), compile=False)

# 导入测试数据并应用预处理
df_test = pd.read_parquet(filepath_data + "df_test.parquet")
ts_pad = df_test.groupby("tsid")["x"].transform(prepare_series, model_type)
df_test["x_pad"] = ts_pad

# 将数据转换为模型输入所需格式
inputs_test = df_test["x_pad"].to_numpy().reshape(-1, ts_len, 1)
targets_test = df_test["type"].iloc[::ts_len].to_numpy().reshape(-1, 1)

# 获取预测结果
preds_prob = model.predict(inputs_test)
preds = np.argmax(preds_prob, axis=1)

# 将预测概率转换为 DataFrame
# 假设有6个类别，preds_prob 的形状应该是 (样本数, 6)
preds_prob_df = pd.DataFrame(preds_prob, columns=range(6))
# 将预测的类别转换为 DataFrame
preds_df = pd.DataFrame(preds, columns=['predicted_labels'])
# 将真实标签转换为 DataFrame
true_labels_df = pd.DataFrame(targets_test.flatten(), columns=['true_labels'])
# 合并三个 DataFrame
results_df = pd.concat([preds_prob_df, true_labels_df, preds_df], axis=1)


import os
base_filename = f"predictions_{model_type}.csv"

# 创建完整的文件路径
full_file_path = os.path.join(filepath_classifier, base_filename)

# 确保子目录存在
os.makedirs(os.path.dirname(full_file_path), exist_ok=True)

# 将预测结果保存到 CSV 文件
results_df.to_csv(full_file_path, index=False)