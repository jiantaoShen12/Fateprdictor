import os

# 定义脚本所在的目录
script_dir = '/home/sjt/workspace/beginning_project/cell_change尝试/dl_train/'

# 定义要运行的脚本列表
#scripts = [ 'dl_train6GRU.py' , 'dl_trainlstm.py', 'dl_train6GRU.py','dl_trainblstm.py'  ]
scripts = ['dl_train6GRU.py', 'dl_trainblstm.py' ]

# 循环遍历脚本列表，执行每个脚本
for script in scripts:
    # 拼接完整的脚本路径
    script_path = os.path.join(script_dir, script)
    # 使用os.system()执行脚本
    os.system(f'python {script_path}')